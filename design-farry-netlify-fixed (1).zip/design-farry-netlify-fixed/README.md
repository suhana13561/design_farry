# design.farry — Netlify portfolio

This is the original React/Vite portfolio with a shared Netlify Functions + Netlify Blobs backend for project publishing.

## Why this fix is needed

The original `src/utils/projectStorage.ts` saved projects only to browser `localStorage` and used a hard-coded frontend passcode (`farry2026`). Browser storage is per browser/device, so newly created work was not shared with public visitors. A frontend passcode is also not secure because it can be inspected in the downloaded JavaScript.

This version loads published projects from a shared Netlify Blobs store, and checks creator credentials in a server-side Netlify Function. The Creator Studio entry point is hidden from public visitors.

## Deploy

1. Push this project folder to a Git repository and import it into Netlify, or upload the project through your normal Git workflow.
2. `netlify.toml` configures `npm run build`, publishes `dist`, and deploys functions from `netlify/functions`.
3. In Netlify, open **Site configuration → Environment variables** and add:
   - `CREATOR_ADMIN_PASSWORD`: a strong, unique password of your choice.
   - `CREATOR_SESSION_SECRET`: a long random secret (at least 32 characters). Do not reuse the admin password.
4. Trigger a fresh deploy after setting the environment variables.
5. Open your public site and confirm it loads. To open the hidden creator login, append `?creator=1` to your site URL, for example `https://your-site.netlify.app/?creator=1`.
6. Sign in with the `CREATOR_ADMIN_PASSWORD` value. The admin controls appear only after authentication.
7. Add or edit a project. Saved projects are written to Netlify Blobs and are then available to other visitors and devices.

## Notes

- Netlify Blobs is the shared persistent store; projects are not stored solely in one visitor's browser anymore.
- Uploaded images are resized and compressed to WebP before saving to reduce request size while preserving transparency.
- The public project list is readable by visitors, but create/update/delete/import operations require a signed creator session.
- The admin login session expires after 12 hours. Sign in again if a save returns a session-expired message.
- If you run this outside Netlify, the `/.netlify/functions/projects` endpoint will not exist unless you use `netlify dev`.
- After the first successful deployment, publish one test project and verify it from a separate browser/device.
