import { getStore } from '@netlify/blobs';
import { createHmac, timingSafeEqual } from 'node:crypto';

const STORE_NAME = 'design-farry-portfolio';
const PROJECTS_KEY = 'projects.json';
const TOKEN_TTL_SECONDS = 60 * 60 * 12;

function jsonResponse(statusCode, payload) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    },
    body: JSON.stringify(payload),
  };
}

function safeEqual(left, right) {
  const a = Buffer.from(String(left || ''));
  const b = Buffer.from(String(right || ''));
  return a.length === b.length && timingSafeEqual(a, b);
}

function createToken() {
  const secret = process.env.CREATOR_SESSION_SECRET;
  const payload = Buffer.from(JSON.stringify({
    exp: Math.floor(Date.now() / 1000) + TOKEN_TTL_SECONDS,
    scope: 'portfolio:write',
  })).toString('base64url');
  const signature = createHmac('sha256', secret).update(payload).digest('base64url');
  return `${payload}.${signature}`;
}

function isAuthorized(event) {
  const secret = process.env.CREATOR_SESSION_SECRET;
  const header = event.headers?.authorization || event.headers?.Authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  const parts = token.split('.');
  if (!secret || parts.length !== 2) return false;

  const expected = createHmac('sha256', secret).update(parts[0]).digest('base64url');
  if (!safeEqual(expected, parts[1])) return false;

  try {
    const payload = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf8'));
    return payload.scope === 'portfolio:write' && payload.exp > Math.floor(Date.now() / 1000);
  } catch {
    return false;
  }
}

async function readProjects() {
  const store = getStore(STORE_NAME);
  const projects = await store.get(PROJECTS_KEY, { type: 'json' });
  return Array.isArray(projects) ? projects : [];
}

async function writeProjects(projects) {
  const store = getStore(STORE_NAME);
  await store.setJSON(PROJECTS_KEY, projects);
  return projects;
}

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return jsonResponse(204, {});
  if (event.httpMethod === 'GET') {
    try {
      return jsonResponse(200, { projects: await readProjects() });
    } catch (error) {
      console.error('Could not load portfolio projects:', error);
      return jsonResponse(500, { error: 'Could not load projects from shared storage.' });
    }
  }

  if (event.httpMethod !== 'POST') {
    return jsonResponse(405, { error: 'Method not allowed.' });
  }

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch {
    return jsonResponse(400, { error: 'Invalid JSON request.' });
  }

  if (body.action === 'login') {
    const expectedPassword = process.env.CREATOR_ADMIN_PASSWORD;
    if (!expectedPassword || !process.env.CREATOR_SESSION_SECRET) {
      return jsonResponse(503, { error: 'Admin login is not configured. Set CREATOR_ADMIN_PASSWORD and CREATOR_SESSION_SECRET in Netlify environment variables.' });
    }
    if (!safeEqual(body.passcode, expectedPassword)) {
      return jsonResponse(401, { error: 'Incorrect creator password.' });
    }
    return jsonResponse(200, { token: createToken() });
  }

  if (!process.env.CREATOR_ADMIN_PASSWORD || !process.env.CREATOR_SESSION_SECRET) {
    return jsonResponse(503, { error: 'Admin storage is not configured in Netlify.' });
  }
  if (!isAuthorized(event)) {
    return jsonResponse(401, { error: 'Your creator session expired. Please sign in again.' });
  }

  try {
    let projects = await readProjects();

    if (body.action === 'save-project') {
      if (!body.project || typeof body.project.id !== 'string' || typeof body.project.title !== 'string') {
        return jsonResponse(400, { error: 'A project ID and title are required.' });
      }
      const index = projects.findIndex((project) => project.id === body.project.id);
      if (index >= 0) {
        projects[index] = body.project;
      } else {
        projects.unshift(body.project);
      }
    } else if (body.action === 'delete-project') {
      if (typeof body.id !== 'string') return jsonResponse(400, { error: 'Project ID is required.' });
      projects = projects.filter((project) => project.id !== body.id);
    } else if (body.action === 'import-projects') {
      if (!Array.isArray(body.projects)) return jsonResponse(400, { error: 'Projects must be a JSON array.' });
      if (body.projects.length > 500) return jsonResponse(413, { error: 'Too many projects in one import.' });
      projects = body.projects;
    } else if (body.action === 'migrate-projects') {
      // Import the previous localStorage portfolio only if no shared projects exist yet.
      if (projects.length === 0 && Array.isArray(body.projects)) {
        if (body.projects.length > 500) return jsonResponse(413, { error: 'Too many projects to migrate.' });
        projects = body.projects;
      }
    } else {
      return jsonResponse(400, { error: 'Unknown action.' });
    }

    await writeProjects(projects);
    return jsonResponse(200, { projects });
  } catch (error) {
    console.error('Portfolio update failed:', error);
    return jsonResponse(500, { error: 'Could not save changes to shared storage.' });
  }
};
