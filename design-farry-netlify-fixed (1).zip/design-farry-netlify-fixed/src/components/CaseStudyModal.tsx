import React, { useState } from 'react';
import { Project } from '../data/portfolioData';

interface CaseStudyModalProps {
  project: Project | null;
  onClose: () => void;
  onInquire: (projectTitle: string) => void;
  isAdmin?: boolean;
  onEditProject?: (project: Project) => void;
}

export const CaseStudyModal: React.FC<CaseStudyModalProps> = ({
  project,
  onClose,
  onInquire,
  isAdmin = false,
  onEditProject,
}) => {
  const [copiedHex, setCopiedHex] = useState<string | null>(null);
  const [activeImageIdx, setActiveImageIdx] = useState<number>(0);

  if (!project) return null;

  const allImages: string[] = [];
  if (project.coverImage) allImages.push(project.coverImage);
  if (project.galleryImages && project.galleryImages.length > 0) {
    project.galleryImages.forEach((img) => {
      if (img && !allImages.includes(img)) allImages.push(img);
    });
  }

  const handleCopyColor = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 1800);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-neutral-950 text-neutral-100 rounded-2xl border border-white/10 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Sticky Header with breadcrumbs & close */}
        <div className="sticky top-0 z-20 flex items-center justify-between px-6 py-4 bg-neutral-950/95 backdrop-blur-md border-b border-white/10">
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span className="text-white font-medium">design.farry</span>
            <span aria-hidden="true">/</span>
            <span>{project.category}</span>
            <span aria-hidden="true">/</span>
            <span className="text-neutral-200 truncate max-w-[200px] sm:max-w-xs">{project.title}</span>
          </div>

          <div className="flex items-center gap-2">
            {isAdmin && onEditProject && (
              <button
                onClick={() => onEditProject(project)}
                className="px-3 py-1.5 rounded-lg bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                title="Edit this project's details and save updates"
              >
                <span>✎</span>
                <span>Edit &amp; Save Project</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              aria-label="Close case study"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto px-6 sm:px-10 py-8 space-y-10">
          {/* Title & Metadata */}
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-400 mb-3">
              <span className="text-white font-medium">{project.category}</span>
              {project.year && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{project.year}</span>
                </>
              )}
              {project.role && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{project.role}</span>
                </>
              )}
              {project.client && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>Client: {project.client}</span>
                </>
              )}
            </div>
            <h2
              className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white mb-4"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              {project.title}
            </h2>
            {project.tagline && (
              <p className="text-lg text-neutral-300 leading-relaxed max-w-2xl">
                {project.tagline}
              </p>
            )}
          </div>

          {/* Project Images Gallery */}
          {allImages.length > 0 ? (
            <div className="space-y-4">
              <div className="rounded-xl overflow-hidden border border-white/10 bg-neutral-900 flex items-center justify-center">
                <img
                  src={allImages[activeImageIdx] || allImages[0]}
                  alt={`${project.title} visual artwork`}
                  referrerPolicy="no-referrer"
                  className="w-full h-auto object-contain max-h-[550px] mx-auto"
                />
              </div>

              {/* Thumbnails if multiple images exist */}
              {allImages.length > 1 && (
                <div className="flex items-center gap-3 overflow-x-auto pb-2">
                  {allImages.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIdx(idx)}
                      className={`relative w-20 h-20 rounded-lg overflow-hidden border shrink-0 transition-all cursor-pointer ${
                        activeImageIdx === idx ? 'border-white scale-95 ring-2 ring-white/30' : 'border-white/20 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img
                        src={img}
                        alt={`Thumbnail ${idx + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="rounded-xl p-10 border border-dashed border-white/15 bg-neutral-900/30 text-center space-y-2">
              <div className="text-xs uppercase tracking-wider text-neutral-400 font-medium">Textual Case Study</div>
              <p className="text-sm text-neutral-300">No external preview image uploaded for this design project.</p>
            </div>
          )}

          {/* Creative Brief & Concept */}
          {(project.brief || project.concept) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4 border-t border-white/10">
              {project.brief && (
                <div>
                  <h3 className="text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-3">
                    01. The Brief &amp; Challenge
                  </h3>
                  <p className="text-sm text-neutral-300 leading-relaxed whitespace-pre-line">
                    {project.brief}
                  </p>
                </div>
              )}
              {project.concept && (
                <div>
                  <h3 className="text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-3">
                    02. Creative Concept
                  </h3>
                  <p className="text-sm text-neutral-300 leading-relaxed whitespace-pre-line">
                    {project.concept}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Visual Direction & Methodology */}
          {project.visualDirection && (
            <div className="p-6 rounded-xl bg-neutral-900/70 border border-white/10">
              <h3 className="text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-2">
                Visual Direction &amp; Layout Grid
              </h3>
              <p className="text-sm text-neutral-200 leading-relaxed whitespace-pre-line">
                {project.visualDirection}
              </p>
            </div>
          )}

          {/* Typography & Color Palette (If specified) */}
          {(project.typography || (project.colorPalette && project.colorPalette.length > 0)) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4 border-t border-white/10">
              {/* Typography */}
              {project.typography && (
                <div>
                  <h3 className="text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-4">
                    Typographic Hierarchy
                  </h3>
                  <div className="space-y-4">
                    {project.typography.heading && (
                      <div className="p-4 rounded-lg bg-neutral-900 border border-white/5">
                        <div className="text-xs text-neutral-400 mb-1">Display / Headlines</div>
                        <div className="text-base font-semibold text-white tracking-tight">{project.typography.heading}</div>
                      </div>
                    )}
                    {project.typography.body && (
                      <div className="p-4 rounded-lg bg-neutral-900 border border-white/5">
                        <div className="text-xs text-neutral-400 mb-1">Body &amp; Secondary Type</div>
                        <div className="text-sm text-neutral-300">{project.typography.body}</div>
                      </div>
                    )}
                    {project.typography.notes && (
                      <p className="text-xs text-neutral-400 italic">
                        Note: {project.typography.notes}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Color Palette */}
              {project.colorPalette && project.colorPalette.length > 0 && (
                <div>
                  <h3 className="text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-4">
                    Color System (Click hex to copy)
                  </h3>
                  <div className="grid grid-cols-2 gap-3">
                    {project.colorPalette.map((c, i) => (
                      <button
                        key={`${c.hex}-${i}`}
                        type="button"
                        onClick={() => handleCopyColor(c.hex)}
                        className="p-3 rounded-lg bg-neutral-900 border border-white/5 hover:border-white/20 transition-all text-left group cursor-pointer"
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <div
                            className="w-5 h-5 rounded border border-white/20 shrink-0 shadow-inner"
                            style={{ backgroundColor: c.hex }}
                          />
                          <span className="font-mono text-xs text-neutral-300 font-medium">{c.hex}</span>
                        </div>
                        <div className="text-xs text-white font-medium">{c.name}</div>
                        {c.role && <div className="text-[11px] text-neutral-400">{c.role}</div>}
                        {copiedHex === c.hex && (
                          <span className="inline-block mt-1 text-[10px] text-emerald-400 font-medium">
                            Copied!
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Process Timeline */}
          {project.process && project.process.length > 0 && (
            <div className="pt-4 border-t border-white/10">
              <h3 className="text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-5">
                Design Process &amp; Stages
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {project.process.map((step, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-neutral-900/50 border border-white/5">
                    <div className="font-mono text-xs text-neutral-400 mb-1">{step.stage || `0${idx + 1}`}</div>
                    <h4 className="text-sm font-semibold text-white mb-2">{step.title}</h4>
                    <p className="text-xs text-neutral-400 leading-relaxed">{step.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Deliverables & Final Outcome */}
          {((project.deliverables && project.deliverables.length > 0) || project.outcome) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-white/10">
              {project.deliverables && project.deliverables.length > 0 && (
                <div>
                  <h3 className="text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-3">
                    Deliverables
                  </h3>
                  <div className="space-y-1.5">
                    {project.deliverables.map((item, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-neutral-300">
                        <svg className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {project.outcome && (
                <div>
                  <h3 className="text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-3">
                    Final Outcome &amp; Impact
                  </h3>
                  <p className="text-xs text-neutral-300 leading-relaxed">
                    {project.outcome}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* External Project Link */}
          {project.externalLink && (
            <div className="pt-2">
              <a
                href={project.externalLink}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 text-xs font-semibold text-white hover:underline underline-offset-4"
              >
                <span>Visit Live Project / Publication</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                  <polyline points="15 3 21 3 21 9" />
                  <line x1="10" y1="14" x2="21" y2="3" />
                </svg>
              </a>
            </div>
          )}

          {/* Bottom Action Footer */}
          <div className="pt-6 border-t border-white/10 flex flex-wrap items-center justify-between gap-4">
            <div className="text-xs text-neutral-400">
              Need a similar visual direction for your project?
            </div>
            <div className="flex flex-wrap items-center gap-3">
              {isAdmin && onEditProject && (
                <button
                  onClick={() => onEditProject(project)}
                  className="px-4 py-2.5 rounded-full bg-emerald-950/90 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 font-semibold text-xs transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <span>✎</span>
                  <span>Edit / Update Work (Admin)</span>
                </button>
              )}
              <button
                onClick={() => {
                  onClose();
                  onInquire(project.title);
                }}
                className="px-5 py-2.5 rounded-full bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition-colors cursor-pointer"
              >
                Inquire about this style
              </button>
              <button
                onClick={onClose}
                className="px-4 py-2.5 rounded-full bg-neutral-800 text-neutral-300 font-medium text-xs hover:bg-neutral-700 transition-colors cursor-pointer"
              >
                Back to portfolio
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
