import React, { useState, useEffect } from 'react';
import { Project, ProjectCategory, matchCategory } from '../data/portfolioData';
import {
  isCreatorAuthenticated,
  authenticateCreator,
  logoutCreator,
  upsertProject,
  deleteProject,
  exportProjectsJson,
  importProjectsJson,
  syncProjectsFromServer,
} from '../utils/projectStorage';

interface CreatorStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  projects: Project[];
  onProjectsUpdated: () => void;
  initialCategory?: ProjectCategory | null;
  initialEditProject?: Project | null;
}

export const CATEGORIES: ProjectCategory[] = [
  'Brand',
  'Posters',
  'Packaging',
  'Advertising',
  'Social Media',
  'Editorial',
  'Other',
];

/**
 * Compress uploaded artwork before sending it to Netlify Functions.
 * WebP preserves transparency and substantially reduces the request size.
 */
function compressImageFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read the selected image.'));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error('The selected file is not a supported image.'));
      image.onload = () => {
        const maxDimension = 1800;
        const scale = Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        const context = canvas.getContext('2d');
        if (!context) {
          reject(new Error('Image compression is not supported in this browser.'));
          return;
        }
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        canvas.toBlob((blob) => {
          if (!blob) {
            reject(new Error('Could not compress the selected image.'));
            return;
          }
          const compressedReader = new FileReader();
          compressedReader.onerror = () => reject(new Error('Could not prepare the compressed image.'));
          compressedReader.onload = () => {
            if (typeof compressedReader.result === 'string') resolve(compressedReader.result);
            else reject(new Error('Could not prepare the compressed image.'));
          };
          compressedReader.readAsDataURL(blob);
        }, 'image/webp', 0.82);
      };
      image.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

export const CreatorStudioModal: React.FC<CreatorStudioModalProps> = ({
  isOpen,
  onClose,
  projects,
  onProjectsUpdated,
  initialCategory = null,
  initialEditProject = null,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(isCreatorAuthenticated());
  const [passcode, setPasscode] = useState('');
  const [authError, setAuthError] = useState(false);

  // Active view: 'manage' | 'editor' | 'json'
  const [activeTab, setActiveTab] = useState<'manage' | 'editor' | 'json'>('manage');
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [savedSuccessMessage, setSavedSuccessMessage] = useState<string | null>(null);

  // Filter within studio manager
  const [studioCategoryFilter, setStudioCategoryFilter] = useState<string>('All');

  // Form State for creating / editing project
  const [form, setForm] = useState<Partial<Project>>({
    title: '',
    category: initialCategory || 'Branding',
    year: new Date().getFullYear().toString(),
    client: '',
    role: '',
    tagline: '',
    coverImage: '',
    galleryImages: [],
    aspectRatio: 'aspect-[4/3]',
    brief: '',
    concept: '',
    visualDirection: '',
    deliverables: [],
    outcome: '',
    externalLink: '',
    featured: false,
  });

  const [rawDeliverables, setRawDeliverables] = useState('');
  const [galleryInputUrl, setGalleryInputUrl] = useState('');
  const [jsonInput, setJsonInput] = useState('');
  const [jsonMessage, setJsonMessage] = useState<string | null>(null);

  // Whenever initialCategory or initialEditProject is provided when opening, switch to editor
  useEffect(() => {
    if (isOpen) {
      if (initialEditProject) {
        if (isCreatorAuthenticated()) {
          startEditProject(initialEditProject);
        } else {
          setEditingProject(initialEditProject);
          setForm({ ...initialEditProject });
          setRawDeliverables((initialEditProject.deliverables || []).join('\n'));
        }
      } else if (initialCategory) {
        if (isCreatorAuthenticated()) {
          startNewProjectWithCategory(initialCategory);
        } else {
          setForm((prev) => ({ ...prev, category: initialCategory }));
        }
      }
    }
  }, [initialCategory, initialEditProject, isOpen]);

  if (!isOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const authenticated = await authenticateCreator(passcode);
    if (authenticated) {
      setIsAuthenticated(true);
      setAuthError(false);
      setPasscode('');
      await syncProjectsFromServer();
      onProjectsUpdated();
      if (initialEditProject) {
        startEditProject(initialEditProject);
      } else if (initialCategory) {
        startNewProjectWithCategory(initialCategory);
      }
    } else {
      setAuthError(true);
    }
  };

  const handleLogout = () => {
    logoutCreator();
    setIsAuthenticated(false);
  };

  const startNewProjectWithCategory = (cat: ProjectCategory = 'Branding') => {
    setEditingProject(null);
    setForm({
      title: '',
      category: cat,
      year: new Date().getFullYear().toString(),
      client: '',
      role: '',
      tagline: '',
      coverImage: '',
      galleryImages: [],
      aspectRatio: 'aspect-[4/3]',
      brief: '',
      concept: '',
      visualDirection: '',
      deliverables: [],
      outcome: '',
      externalLink: '',
      featured: false,
    });
    setRawDeliverables('');
    setActiveTab('editor');
  };

  const startEditProject = (p: Project) => {
    setEditingProject(p);
    setForm({ ...p });
    setRawDeliverables((p.deliverables || []).join('\n'));
    setActiveTab('editor');
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to remove this project from your portfolio?')) return;
    try {
      await deleteProject(id);
      onProjectsUpdated();
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Could not delete the project. Check your connection and try again.');
    }
  };

  // Compress images before saving them to shared project storage.
  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const coverImage = await compressImageFile(file);
      setForm((prev) => ({ ...prev, coverImage }));
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Could not process this image.');
    }
  };

  const handleGalleryUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    try {
      const compressedImages = await Promise.all(Array.from(files).map(compressImageFile));
      setForm((prev) => ({
        ...prev,
        galleryImages: [...(prev.galleryImages || []), ...compressedImages],
      }));
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Could not process one or more images.');
    }
  };

  const addGalleryUrl = () => {
    if (galleryInputUrl.trim()) {
      setForm((prev) => ({
        ...prev,
        galleryImages: [...(prev.galleryImages || []), galleryInputUrl.trim()],
      }));
      setGalleryInputUrl('');
    }
  };

  const removeGalleryImage = (index: number) => {
    setForm((prev) => ({
      ...prev,
      galleryImages: (prev.galleryImages || []).filter((_, i) => i !== index),
    }));
  };

  const handleSaveProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.category) return;

    const deliverablesList = rawDeliverables
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    const newProject: Project = {
      id: editingProject?.id || `proj-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      title: form.title || 'Untitled Project',
      category: form.category || 'Branding',
      year: form.year || new Date().getFullYear().toString(),
      client: form.client || '',
      role: form.role || 'Graphic Designer',
      tagline: form.tagline || '',
      coverImage: form.coverImage || '',
      galleryImages: form.galleryImages || [],
      aspectRatio: form.aspectRatio || 'aspect-[4/3]',
      brief: form.brief || '',
      concept: form.concept || '',
      visualDirection: form.visualDirection || '',
      deliverables: deliverablesList,
      outcome: form.outcome || '',
      externalLink: form.externalLink || '',
      featured: form.featured || false,
    };

    try {
      await upsertProject(newProject);
      onProjectsUpdated();
      setSavedSuccessMessage(
        editingProject
          ? `Successfully saved and updated "${newProject.title}"!`
          : `Successfully published "${newProject.title}" to portfolio!`
      );
      setTimeout(() => setSavedSuccessMessage(null), 3500);
      setActiveTab('manage');
    } catch (error) {
      setSavedSuccessMessage(error instanceof Error ? `Save failed: ${error.message}` : 'Save failed. Check your connection and Netlify setup.');
    }
  };

  const handleImportJson = async () => {
    if (!jsonInput.trim()) return;
    const ok = await importProjectsJson(jsonInput);
    if (ok) {
      setJsonMessage('Projects successfully imported & saved to shared storage!');
      onProjectsUpdated();
      setTimeout(() => setJsonMessage(null), 3000);
    } else {
      setJsonMessage('Import failed. Check JSON format, login, and Netlify configuration.');
    }
  };

  // Filter projects inside manage view
  const displayedProjects =
    studioCategoryFilter === 'All'
      ? projects
      : projects.filter((p) => matchCategory(p.category, studioCategoryFilter));

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-neutral-950 text-neutral-100 rounded-2xl border border-white/10 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 z-20 flex items-center justify-between px-6 py-4 bg-neutral-950/95 backdrop-blur-md border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h2 className="text-base font-bold text-white tracking-tight">
              design.farry &middot; Creator Studio
            </h2>
            <span className="text-[11px] font-mono text-neutral-400 bg-neutral-900 px-2 py-0.5 rounded border border-white/10">
              Admin Only
            </span>
          </div>

          <div className="flex items-center gap-3">
            {isAuthenticated && (
              <button
                onClick={handleLogout}
                className="text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
              >
                Sign out
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              aria-label="Close studio"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          </div>
        </div>

        {/* Studio Content */}
        {!isAuthenticated ? (
          /* Authentication Screen */
          <div className="p-8 sm:p-12 text-center max-w-md mx-auto my-auto space-y-6">
            <div className="w-12 h-12 rounded-full bg-neutral-900 border border-white/15 flex items-center justify-center mx-auto text-white">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                <path d="M7 11V7a5 5 0 0 1 10 0v4" />
              </svg>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white mb-2">Creator Access Required</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                This panel is strictly for you as the creator of design.farry to edit and post your actual work. It is never visible to visitors or clients.
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <input
                  type="password"
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  placeholder="Enter your creator password"
                  autoFocus
                  className="w-full px-4 py-3 rounded-xl bg-neutral-900 border border-white/15 text-sm text-center text-white placeholder-neutral-500 focus:outline-none focus:border-white transition-colors"
                />
                {authError && (
                  <p className="text-xs text-rose-400 mt-2">
                    Incorrect password, or the Netlify admin password is not configured.
                  </p>
                )}
              </div>
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition-colors cursor-pointer"
              >
                Unlock Studio &rarr;
              </button>
            </form>
          </div>
        ) : (
          /* Authenticated Creator Workspace */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Tabs Bar */}
            <div className="px-6 py-2.5 bg-neutral-900/50 border-b border-white/10 flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('manage')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    activeTab === 'manage'
                      ? 'bg-white text-black font-semibold'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  All Projects ({projects.length})
                </button>
                <button
                  onClick={() => startNewProjectWithCategory('Branding')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    activeTab === 'editor'
                      ? 'bg-white text-black font-semibold'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  + Post New Work
                </button>
                <button
                  onClick={() => {
                    setJsonInput(exportProjectsJson());
                    setActiveTab('json');
                  }}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    activeTab === 'json'
                      ? 'bg-white text-black font-semibold'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Export / Import JSON
                </button>
              </div>

              <div className="text-[11px] text-neutral-400 hidden sm:block">
                Auto-saves to browser storage &middot; Immediate live reflection
              </div>
            </div>

            {/* Success notification banner */}
            {savedSuccessMessage && (
              <div className="mx-6 mt-4 p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs flex items-center justify-between gap-3 animate-fadeIn">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span className="font-semibold text-white">{savedSuccessMessage}</span>
                </div>
                <button
                  onClick={() => setSavedSuccessMessage(null)}
                  className="text-emerald-400 hover:text-white text-xs font-bold px-2 py-0.5"
                >
                  &times;
                </button>
              </div>
            )}

            {/* Quick Post by Category Bar */}
            <div className="px-6 py-3 bg-neutral-950/80 border-b border-white/5 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 text-neutral-400">
                <span className="font-semibold text-white uppercase tracking-wider text-[11px]">
                  Post Work by Type:
                </span>
                <span className="text-[11px]">(Click any type to post directly)</span>
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => startNewProjectWithCategory(cat)}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-md bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border border-white/10 hover:border-white/30 transition-all cursor-pointer flex items-center gap-1"
                    title={`Post new ${cat} project`}
                  >
                    <span>+</span>
                    <span>{cat}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Tab Views */}
            <div className="flex-1 overflow-y-auto p-6 sm:p-8">
              {/* TAB 1: MANAGE PROJECTS */}
              {activeTab === 'manage' && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-bold text-white">Your Real Portfolio Projects</h3>
                      <p className="text-xs text-neutral-400">
                        {projects.length === 0
                          ? 'No projects posted yet. Click any category above or "+ Post New Work" to publish.'
                          : `${projects.length} project(s) live in your portfolio.`}
                      </p>
                    </div>

                    {/* Filter by Category inside studio */}
                    {projects.length > 0 && (
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-neutral-400">Filter:</span>
                        <select
                          value={studioCategoryFilter}
                          onChange={(e) => setStudioCategoryFilter(e.target.value)}
                          className="px-2.5 py-1.5 rounded-lg bg-neutral-900 border border-white/10 text-xs text-white focus:outline-none"
                        >
                          <option value="All">All Types ({projects.length})</option>
                          {CATEGORIES.map((cat) => {
                            const count = projects.filter((p) => p.category === cat).length;
                            return (
                              <option key={cat} value={cat}>
                                {cat} ({count})
                              </option>
                            );
                          })}
                        </select>
                      </div>
                    )}
                  </div>

                  {projects.length === 0 ? (
                    <div className="p-12 text-center rounded-2xl border border-dashed border-white/15 bg-neutral-900/30 space-y-5">
                      <div className="w-12 h-12 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center mx-auto text-neutral-400">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
                          <circle cx="8.5" cy="8.5" r="1.5" />
                          <polyline points="21 15 16 10 5 21" />
                        </svg>
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-white">Your Portfolio is Clean &amp; Ready</div>
                        <p className="text-xs text-neutral-400 max-w-md mx-auto mt-1 leading-relaxed">
                          All fake and sample AI projects have been cleared. Select a discipline below to post your first real project:
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center justify-center gap-2 max-w-lg mx-auto pt-2">
                        {CATEGORIES.map((cat) => (
                          <button
                            key={cat}
                            onClick={() => startNewProjectWithCategory(cat)}
                            className="px-3.5 py-1.5 rounded-lg bg-white/10 hover:bg-white hover:text-black text-white text-xs font-medium border border-white/10 transition-colors cursor-pointer"
                          >
                            + Post {cat}
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : displayedProjects.length === 0 ? (
                    <div className="p-8 text-center rounded-xl border border-white/10 bg-neutral-900/30 text-neutral-400 text-xs">
                      No projects currently found in <span className="text-white font-medium">{studioCategoryFilter}</span>.
                      <button
                        onClick={() => startNewProjectWithCategory(studioCategoryFilter as ProjectCategory)}
                        className="ml-2 text-white underline"
                      >
                        Post a {studioCategoryFilter} project &rarr;
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {displayedProjects.map((p) => (
                        <div
                          key={p.id}
                          className="p-4 rounded-xl bg-neutral-900/70 border border-white/10 flex items-start gap-4 hover:border-white/20 transition-all"
                        >
                          {p.coverImage ? (
                            <img
                              src={p.coverImage}
                              alt={p.title}
                              className="w-20 h-20 rounded-lg object-cover bg-neutral-950 shrink-0 border border-white/10"
                            />
                          ) : (
                            <div className="w-20 h-20 rounded-lg bg-neutral-950 shrink-0 border border-white/10 flex items-center justify-center text-[10px] text-neutral-400">
                              No image
                            </div>
                          )}

                          <div className="flex-1 min-w-0 space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-semibold uppercase text-neutral-300 bg-white/5 px-2 py-0.5 rounded border border-white/10">
                                {p.category}
                              </span>
                              {p.year && (
                                <span className="text-[10px] text-neutral-400">&middot; {p.year}</span>
                              )}
                            </div>
                            <h4 className="text-base font-bold text-white truncate">{p.title}</h4>
                            <p className="text-xs text-neutral-400 line-clamp-1">{p.tagline || p.client}</p>

                            <div className="pt-2 flex items-center gap-3 text-xs">
                              <button
                                onClick={() => startEditProject(p)}
                                className="text-neutral-300 hover:text-white underline cursor-pointer"
                              >
                                Edit
                              </button>
                              <button
                                onClick={() => handleDelete(p.id)}
                                className="text-rose-400 hover:text-rose-300 underline cursor-pointer"
                              >
                                Delete
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: PROJECT EDITOR */}
              {activeTab === 'editor' && (
                <form onSubmit={handleSaveProject} className="space-y-6 max-w-2xl mx-auto">
                  <div className="flex items-center justify-between pb-4 border-b border-white/10">
                    <div>
                      <h3 className="text-lg font-bold text-white">
                        {editingProject ? `Edit: ${editingProject.title}` : `Post New ${form.category || 'Graphic Design'} Work`}
                      </h3>
                      <p className="text-xs text-neutral-400">
                        Fill in your real project information. Only filled sections will appear on your public case study.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveTab('manage')}
                      className="text-xs text-neutral-400 hover:text-white"
                    >
                      &larr; Back to list
                    </button>
                  </div>

                  {/* Title & Category Selector */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        Project Title *
                      </label>
                      <input
                        required
                        type="text"
                        value={form.title}
                        onChange={(e) => setForm({ ...form, title: e.target.value })}
                        placeholder="e.g. Minimalist Poster Exhibition"
                        className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-white/10 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        Work Type / Category *
                      </label>
                      <select
                        value={form.category}
                        onChange={(e) =>
                          setForm({ ...form, category: e.target.value as ProjectCategory })
                        }
                        className="w-full px-3 py-2.5 rounded-xl bg-neutral-900 border border-white/10 text-sm text-white focus:outline-none focus:border-white"
                      >
                        {CATEGORIES.map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Year, Client, Role */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        Year
                      </label>
                      <input
                        type="text"
                        value={form.year}
                        onChange={(e) => setForm({ ...form, year: e.target.value })}
                        placeholder="2026"
                        className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-white/10 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        Client / Context
                      </label>
                      <input
                        type="text"
                        value={form.client}
                        onChange={(e) => setForm({ ...form, client: e.target.value })}
                        placeholder="e.g. Cultural Institute or Self-Initiated"
                        className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-white/10 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        Your Role
                      </label>
                      <input
                        type="text"
                        value={form.role}
                        onChange={(e) => setForm({ ...form, role: e.target.value })}
                        placeholder="e.g. Lead Designer"
                        className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-white/10 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                  </div>

                  {/* Short Tagline / Summary */}
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                      Short Description / Tagline *
                    </label>
                    <input
                      required
                      type="text"
                      value={form.tagline}
                      onChange={(e) => setForm({ ...form, tagline: e.target.value })}
                      placeholder="One-sentence impact summary displayed on the project card..."
                      className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-white/10 text-sm text-white focus:outline-none focus:border-white"
                    />
                  </div>

                  {/* Cover Image Upload & URL */}
                  <div className="p-4 rounded-xl bg-neutral-900/60 border border-white/10 space-y-4">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-white uppercase tracking-wider">
                        Primary Artwork / Cover Image
                      </label>
                      <span className="text-[11px] text-neutral-400">Upload file from device or enter URL</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                      <div>
                        <label className="block text-[11px] text-neutral-400 mb-1">
                          Upload file from your computer:
                        </label>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleCoverUpload}
                          className="w-full text-xs text-neutral-400 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-white file:text-black hover:file:bg-neutral-200 cursor-pointer"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] text-neutral-400 mb-1">
                          Or direct image URL:
                        </label>
                        <input
                          type="text"
                          value={form.coverImage || ''}
                          onChange={(e) => setForm({ ...form, coverImage: e.target.value })}
                          placeholder="https://..."
                          className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-white/10 text-xs text-white focus:outline-none focus:border-white"
                        />
                      </div>
                    </div>

                    {form.coverImage && (
                      <div className="pt-2 flex items-center gap-4">
                        <img
                          src={form.coverImage}
                          alt="Cover preview"
                          className="w-24 h-24 rounded-lg object-cover border border-white/20 bg-black"
                        />
                        <div className="space-y-1">
                          <span className="text-xs text-emerald-400 font-medium block">&check; Image Loaded</span>
                          <button
                            type="button"
                            onClick={() => setForm({ ...form, coverImage: '' })}
                            className="text-xs text-rose-400 hover:underline cursor-pointer"
                          >
                            Remove image
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Multiple Gallery Images */}
                  <div className="p-4 rounded-xl bg-neutral-900/60 border border-white/10 space-y-4">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-white uppercase tracking-wider">
                        Additional Project Gallery Images (Optional)
                      </label>
                      <span className="text-[11px] text-neutral-400">Multiple mockups/sketches/deliverables</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[11px] text-neutral-400 mb-1">
                          Upload multiple files:
                        </label>
                        <input
                          type="file"
                          accept="image/*"
                          multiple
                          onChange={handleGalleryUpload}
                          className="w-full text-xs text-neutral-400 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-neutral-800 file:text-white hover:file:bg-neutral-700 cursor-pointer"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] text-neutral-400 mb-1">
                          Add by URL:
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={galleryInputUrl}
                            onChange={(e) => setGalleryInputUrl(e.target.value)}
                            placeholder="https://..."
                            className="flex-1 px-3 py-2 rounded-lg bg-neutral-950 border border-white/10 text-xs text-white"
                          />
                          <button
                            type="button"
                            onClick={addGalleryUrl}
                            className="px-3 py-2 rounded-lg bg-neutral-800 text-xs text-white hover:bg-neutral-700 cursor-pointer"
                          >
                            Add
                          </button>
                        </div>
                      </div>
                    </div>

                    {form.galleryImages && form.galleryImages.length > 0 && (
                      <div className="flex flex-wrap gap-3 pt-2">
                        {form.galleryImages.map((img, i) => (
                          <div key={i} className="relative group w-16 h-16 rounded-lg overflow-hidden border border-white/20">
                            <img src={img} alt={`Gallery item ${i}`} className="w-full h-full object-cover" />
                            <button
                              type="button"
                              onClick={() => removeGalleryImage(i)}
                              className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 flex items-center justify-center text-xs text-rose-400 font-bold transition-opacity cursor-pointer"
                            >
                              ✕
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Case Study Details */}
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        The Brief &amp; Challenge
                      </label>
                      <textarea
                        rows={3}
                        value={form.brief || ''}
                        onChange={(e) => setForm({ ...form, brief: e.target.value })}
                        placeholder="What problem or opportunity did this design solve?"
                        className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-white/10 text-xs text-white focus:outline-none focus:border-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        Creative Concept &amp; Approach
                      </label>
                      <textarea
                        rows={3}
                        value={form.concept || ''}
                        onChange={(e) => setForm({ ...form, concept: e.target.value })}
                        placeholder="What was the big idea, visual metaphor, or strategy?"
                        className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-white/10 text-xs text-white focus:outline-none focus:border-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        Visual Direction / Grid System
                      </label>
                      <textarea
                        rows={2}
                        value={form.visualDirection || ''}
                        onChange={(e) => setForm({ ...form, visualDirection: e.target.value })}
                        placeholder="Grid system, composition balance, materials, finishes..."
                        className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-white/10 text-xs text-white focus:outline-none focus:border-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        Deliverables (One per line)
                      </label>
                      <textarea
                        rows={3}
                        value={rawDeliverables}
                        onChange={(e) => setRawDeliverables(e.target.value)}
                        placeholder="Poster A0 screenprint&#10;Brand Guidelines PDF&#10;Custom Packaging Die-lines"
                        className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-white/10 text-xs text-white focus:outline-none focus:border-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        External Link / Live URL (Optional)
                      </label>
                      <input
                        type="url"
                        value={form.externalLink || ''}
                        onChange={(e) => setForm({ ...form, externalLink: e.target.value })}
                        placeholder="https://..."
                        className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-white/10 text-xs text-white focus:outline-none focus:border-white"
                      />
                    </div>
                  </div>

                  {/* Form Submission Actions */}
                  <div className="pt-4 flex items-center justify-between border-t border-white/10">
                    <button
                      type="button"
                      onClick={() => setActiveTab('manage')}
                      className="px-4 py-2 text-xs text-neutral-400 hover:text-white cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2.5 rounded-full bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition-colors cursor-pointer flex items-center gap-2"
                    >
                      <span>{editingProject ? 'Save Changes & Update Live Project' : 'Save Project to Portfolio'}</span>
                      <span>&rarr;</span>
                    </button>
                  </div>
                </form>
              )}

              {/* TAB 3: EXPORT / IMPORT JSON */}
              {activeTab === 'json' && (
                <div className="space-y-6 max-w-2xl mx-auto">
                  <div>
                    <h3 className="text-lg font-bold text-white mb-1">Persistent Backup &amp; Code Sync</h3>
                    <p className="text-xs text-neutral-400 leading-relaxed">
                      You can copy this JSON directly into <span className="font-mono text-white">src/data/portfolioData.ts</span> under <span className="font-mono text-white">INITIAL_PROJECTS</span> to commit it permanently into git/repository! Or paste a JSON backup to restore projects anytime.
                    </p>
                  </div>

                  {jsonMessage && (
                    <div className="p-3 rounded-lg bg-neutral-900 border border-emerald-500/30 text-xs text-emerald-400">
                      {jsonMessage}
                    </div>
                  )}

                  <div>
                    <textarea
                      rows={14}
                      value={jsonInput}
                      onChange={(e) => setJsonInput(e.target.value)}
                      className="w-full p-4 rounded-xl bg-neutral-950 font-mono text-xs text-neutral-200 border border-white/10 focus:outline-none focus:border-white"
                    />
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(jsonInput);
                        setJsonMessage('Copied JSON to clipboard! Paste it into src/data/portfolioData.ts to make it permanent in code.');
                        setTimeout(() => setJsonMessage(null), 4000);
                      }}
                      className="px-4 py-2 rounded-lg bg-neutral-800 text-xs text-white hover:bg-neutral-700 transition-colors cursor-pointer"
                    >
                      Copy JSON to Clipboard
                    </button>

                    <button
                      type="button"
                      onClick={handleImportJson}
                      className="px-5 py-2 rounded-lg bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition-colors cursor-pointer"
                    >
                      Import &amp; Apply JSON
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
