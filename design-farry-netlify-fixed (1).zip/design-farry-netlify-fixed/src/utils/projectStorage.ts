import { Project, INITIAL_PROJECTS } from '../data/portfolioData';

const STORAGE_KEY = 'design_farry_portfolio_projects_v1';
const CREATOR_KEY = 'design_farry_creator_access';
const API_URL = '/.netlify/functions/projects';

function readCache(): Project[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed as Project[];
    }
  } catch (err) {
    console.error('Failed to read project cache:', err);
  }
  return INITIAL_PROJECTS;
}

function writeCache(projects: Project[], dispatchUpdate = true): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
    if (dispatchUpdate) window.dispatchEvent(new Event('portfolio-projects-updated'));
  } catch (err) {
    console.error('Failed to cache projects locally:', err);
  }
}

function getToken(): string {
  try {
    return sessionStorage.getItem(CREATOR_KEY) || '';
  } catch {
    return '';
  }
}

async function apiRequest<T>(body: Record<string, unknown>, authenticated = true): Promise<T> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (authenticated && getToken()) headers.Authorization = `Bearer ${getToken()}`;

  const response = await fetch(API_URL, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(typeof result.error === 'string' ? result.error : 'The request could not be completed.');
  }
  return result as T;
}

/** Returns the local cache for immediate first paint; syncProjectsFromServer refreshes it. */
export function getSavedProjects(): Project[] {
  return readCache();
}

/** Pull published projects from shared Netlify Blobs storage. */
export async function syncProjectsFromServer(): Promise<Project[]> {
  try {
    const response = await fetch(API_URL, { method: 'GET', headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error('Unable to load published projects.');
    const result = await response.json();
    const projects = Array.isArray(result.projects) ? result.projects as Project[] : [];
    const cachedProjects = readCache();
    // Preserve legacy browser-only projects until the owner logs in and migrates them.
    if (projects.length === 0 && cachedProjects.length > 0) {
      return cachedProjects;
    }
    writeCache(projects, false);
    return projects;
  } catch (err) {
    console.error('Project sync failed; showing cached projects if available:', err);
    return readCache();
  }
}

export async function upsertProject(project: Project): Promise<Project[]> {
  const result = await apiRequest<{ projects: Project[] }>({ action: 'save-project', project });
  writeCache(result.projects);
  return result.projects;
}

export async function deleteProject(id: string): Promise<Project[]> {
  const result = await apiRequest<{ projects: Project[] }>({ action: 'delete-project', id });
  writeCache(result.projects);
  return result.projects;
}

export function exportProjectsJson(): string {
  return JSON.stringify(readCache(), null, 2);
}

export async function importProjectsJson(jsonString: string): Promise<boolean> {
  try {
    const parsed = JSON.parse(jsonString);
    if (!Array.isArray(parsed)) return false;
    const result = await apiRequest<{ projects: Project[] }>({ action: 'import-projects', projects: parsed });
    writeCache(result.projects);
    return true;
  } catch (err) {
    console.error('Failed to import projects:', err);
    return false;
  }
}

export function isCreatorAuthenticated(): boolean {
  return Boolean(getToken());
}

export async function authenticateCreator(passcode: string): Promise<boolean> {
  try {
    const result = await apiRequest<{ token: string }>({ action: 'login', passcode }, false);
    if (!result.token) return false;
    sessionStorage.setItem(CREATOR_KEY, result.token);
    // One-time migration: copy any projects saved by the old browser-only version
    // into shared storage if the shared portfolio is still empty.
    const cachedProjects = readCache();
    if (cachedProjects.length > 0) {
      try {
        const migrated = await apiRequest<{ projects: Project[] }>({
          action: 'migrate-projects',
          projects: cachedProjects,
        });
        writeCache(migrated.projects, false);
      } catch (migrationError) {
        console.warn('Legacy project migration was skipped:', migrationError);
      }
    }
    return true;
  } catch (err) {
    console.error('Creator login failed:', err);
    return false;
  }
}

export function logoutCreator(): void {
  try {
    sessionStorage.removeItem(CREATOR_KEY);
  } catch {
    // Ignore unavailable session storage.
  }
}
