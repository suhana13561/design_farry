export type ProjectCategory =
  | 'Brand'
  | 'Branding'
  | 'Posters'
  | 'Poster'
  | 'Packaging'
  | 'Package'
  | 'Advertising'
  | 'Social Media'
  | 'Editorial'
  | 'Other';

export const ALL_DISPLAY_CATEGORIES = [
  'Brand',
  'Posters',
  'Packaging',
  'Advertising',
  'Social Media',
  'Editorial',
  'Other',
] as const;

export type DisplayCategory = typeof ALL_DISPLAY_CATEGORIES[number];

export function matchCategory(projectCategory: string, filterCategory: string): boolean {
  if (!filterCategory || filterCategory === 'All') return true;
  const p = (projectCategory || '').toLowerCase().trim();
  const f = filterCategory.toLowerCase().trim();
  if (p === f) return true;
  if ((f === 'brand' || f === 'branding') && (p === 'brand' || p === 'branding')) return true;
  if ((f === 'package' || f === 'packaging') && (p === 'package' || p === 'packaging')) return true;
  if ((f === 'poster' || f === 'posters') && (p === 'poster' || p === 'posters')) return true;
  return false;
}

export interface ProjectColor {
  hex: string;
  name: string;
  role?: string;
}

export interface ProjectProcessStep {
  stage: string;
  title: string;
  description: string;
}

export interface Project {
  id: string;
  title: string;
  category: ProjectCategory;
  year: string;
  client?: string;
  role?: string;
  tagline: string;
  coverImage?: string; // Real image URL or base64 data URI
  galleryImages?: string[]; // Multiple high-res project artwork images
  aspectRatio?: 'aspect-[3/4]' | 'aspect-[4/3]' | 'aspect-[1/1]' | 'aspect-[16/9]' | string;
  brief?: string;
  concept?: string;
  visualDirection?: string;
  typography?: {
    heading?: string;
    body?: string;
    notes?: string;
  };
  colorPalette?: ProjectColor[];
  process?: ProjectProcessStep[];
  deliverables?: string[];
  outcome?: string;
  externalLink?: string;
  featured?: boolean;
  createdAt?: string;
}

export interface Service {
  index: string;
  title: string;
  summary: string;
  details: string;
  deliverables: string[];
  typicalTimeline: string;
}

/**
 * DEFAULT / INITIAL PROJECTS
 * By default, this starts empty so no fake or sample AI projects are presented as Farry's work.
 * When Farry adds real projects via the Creator Studio (or by editing this array), they will appear here.
 */
export const INITIAL_PROJECTS: Project[] = [];

export const SERVICES: Service[] = [
  {
    index: '01',
    title: 'Brand Identity & Systems',
    summary: 'Strategic visual identities engineered to stand out in noisy markets and endure for decades.',
    details:
      'From custom-crafted logomarks and typographic palettes to comprehensive design tokens and brand architecture manuals, I build cohesive visual systems that scale effortlessly across physical and digital touchpoints.',
    deliverables: [
      'Custom Primary Wordmark & Monograms',
      'Curated Typography System & Licensing Specs',
      'Harmonious Color Palette & Spatial Tokens',
      'Comprehensive Brand Guidelines Book (PDF & Digital)',
      'Stationery & Digital Collateral Suite',
    ],
    typicalTimeline: '4–6 Weeks',
  },
  {
    index: '02',
    title: 'Editorial & Poster Design',
    summary: 'High-impact cultural posters, monographs, exhibition collateral, and editorial publications.',
    details:
      'Rooted in international typographic discipline and expressive modern art direction, I design printed and digital publications that command physical presence and provoke intellectual curiosity.',
    deliverables: [
      'Exhibition & Event Posters (A0, B1, Digital)',
      'Books, Catalogs & Exhibition Monographs',
      'Editorial Magazine Spreads & Layouts',
      'Art Direction for Cultural Institutions',
      'Pre-Press Production & Print Spec Supervision',
    ],
    typicalTimeline: '2–4 Weeks',
  },
  {
    index: '03',
    title: 'Campaign & Advertising Creatives',
    summary: 'Omnichannel key visuals that stop thumbs, turn heads, and translate complex ideas into clear emotion.',
    details:
      'I develop bold creative concepts and translate them into full-scale advertising rollouts—from massive outdoor billboards to transit lightboxes and responsive digital display networks.',
    deliverables: [
      'Primary Campaign Key Visual Concept',
      'Large-Format Billboard & Transit Displays',
      'Digital Display Advertising Suite',
      'Social Media Key Creative Sets (Motion & Static)',
      'Art Direction Guidelines for Content Production',
    ],
    typicalTimeline: '3–5 Weeks',
  },
  {
    index: '04',
    title: 'Bespoke Packaging Design',
    summary: 'Tactile packaging experiences that celebrate materiality, unboxing ritual, and shelf magnetism.',
    details:
      'Packaging is a physical brand ambassador in consumers hands. I design structural packaging, labels, custom unboxing experiences, and sustainable materials that build emotional loyalty.',
    deliverables: [
      'Primary Container & Label Design (Bottles, Jars, Tins)',
      'Secondary Box & Structural Outer Carton',
      'Foil, Emboss & Varnish Print Specs',
      'Sustainable Substrate & Paper Selection',
      '3D Photorealistic Retail Mockups',
    ],
    typicalTimeline: '4–8 Weeks',
  },
  {
    index: '05',
    title: 'Social & Digital Creative Direction',
    summary: 'Elevated visual content systems that transform social feeds into curated design galleries.',
    details:
      'Moving beyond cookie-cutter templates, I design bespoke grid identities, typography reels, and animated editorial carousels that establish authentic design authority online.',
    deliverables: [
      'Social Visual Identity System & Grid Architecture',
      'Kinetic Motion Templates (After Effects & Figma)',
      'Editorial Story & Carousel Design Kits',
      'Campaign Launch Social Toolkits',
      'Content Production Best Practices Guide',
    ],
    typicalTimeline: '2–3 Weeks',
  },
];

export const PHILOSOPHY_PRINCIPLES = [
  {
    number: '01',
    title: 'Structure Enables Surprise',
    text: 'A rigorous mathematical grid is not a prison—it is the springboard that makes deliberate asymmetry, oversized typography, and unexpected color vibrate with purpose.',
  },
  {
    number: '02',
    title: 'Tactility in the Digital Era',
    text: 'Even in pixels, good design remembers paper, ink, stone, and light. We engineer depth, texture, and physical friction into every layout so it feels built by human hands.',
  },
  {
    number: '03',
    title: 'Type as Primary Architecture',
    text: 'Typography is the foundation of meaning. When typography is chosen and spaced with obsessive care, extra decoration becomes redundant.',
  },
  {
    number: '04',
    title: 'Elegance Through Reduction',
    text: 'Great work is achieved not when there is nothing left to add, but when nothing can be removed without collapsing the soul of the message.',
  },
];
