/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useTypewriter } from './useTypewriter.ts';
import { SERVICES, PHILOSOPHY_PRINCIPLES, Project, ProjectCategory, matchCategory } from './data/portfolioData.ts';
import { CaseStudyModal } from './components/CaseStudyModal.tsx';
import { CreatorStudioModal, CATEGORIES } from './components/CreatorStudioModal.tsx';
import { getSavedProjects, isCreatorAuthenticated, logoutCreator, syncProjectsFromServer } from './utils/projectStorage.ts';

export default function App() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const isSeekingRef = useRef(false);
  const targetTimeRef = useRef(0);
  const prevXRef = useRef<number | null>(null);

  // Portfolio projects state (loaded from storage/data - completely visible to all visitors and clients)
  const [projects, setProjects] = useState<Project[]>(() => getSavedProjects());

  // UI state
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeCaseStudy, setActiveCaseStudy] = useState<Project | null>(null);
  const [creatorStudioOpen, setCreatorStudioOpen] = useState(false);
  const [initialStudioCategory, setInitialStudioCategory] = useState<ProjectCategory | null>(null);
  const [initialStudioEditProject, setInitialStudioEditProject] = useState<Project | null>(null);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [activeServiceTab, setActiveServiceTab] = useState<number>(0);

  // Creator admin state (only for creator Farry to edit and post work)
  const [isCreatorLoggedIn, setIsCreatorLoggedIn] = useState<boolean>(() => isCreatorAuthenticated());

  // Contact Form State
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    serviceType: 'Brand Identity',
    budget: '$6,000–$12,000',
    timeline: '1–2 Months',
    message: '',
  });
  const [formSubmitted, setFormSubmitted] = useState(false);

  // Typewriter intro in Hero
  const typewriterText =
    "Hello, I'm Farry. I design brand identities, exhibition posters, and tactile packaging systems that command attention and outlast trends.";
  const { displayed, done } = useTypewriter(typewriterText, 32, 400);

  // Sync projects and auth status when updated from storage
  const reloadProjects = useCallback(async () => {
    const latestProjects = await syncProjectsFromServer();
    setProjects(latestProjects);
    setIsCreatorLoggedIn(isCreatorAuthenticated());
  }, []);

  useEffect(() => {
    void reloadProjects();
    const handleUpdate = () => {
      setProjects(getSavedProjects());
      setIsCreatorLoggedIn(isCreatorAuthenticated());
    };
    window.addEventListener('portfolio-projects-updated', handleUpdate);
    return () => window.removeEventListener('portfolio-projects-updated', handleUpdate);
  }, [reloadProjects]);

  // Hidden creator entry point: append ?creator=1 to the site URL.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('creator') === '1') {
      setCreatorStudioOpen(true);
    }
  }, []);

  // Mouse / Touch video scrubber logic
  const seekToTarget = useCallback(() => {
    const video = videoRef.current;
    if (!video || !video.duration || isSeekingRef.current) return;

    if (Math.abs(video.currentTime - targetTimeRef.current) > 0.02) {
      isSeekingRef.current = true;
      video.currentTime = targetTimeRef.current;
    }
  }, []);

  const handleSeeked = useCallback(() => {
    isSeekingRef.current = false;
    const video = videoRef.current;
    if (!video || !video.duration) return;

    if (Math.abs(video.currentTime - targetTimeRef.current) > 0.02) {
      isSeekingRef.current = true;
      video.currentTime = targetTimeRef.current;
    }
  }, []);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (window.scrollY > window.innerHeight) return;

      if (prevXRef.current === null) {
        prevXRef.current = e.clientX;
        return;
      }
      const delta = e.clientX - prevXRef.current;
      prevXRef.current = e.clientX;

      const video = videoRef.current;
      if (!video || !video.duration) return;

      const SENSITIVITY = 0.8;
      const timeDelta = (delta / window.innerWidth) * SENSITIVITY * video.duration;

      targetTimeRef.current = Math.min(Math.max(0, targetTimeRef.current + timeDelta), video.duration);
      seekToTarget();
    };

    const handleMouseLeave = () => {
      prevXRef.current = null;
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (window.scrollY > window.innerHeight || e.touches.length === 0) return;
      const currentX = e.touches[0].clientX;
      if (prevXRef.current === null) {
        prevXRef.current = currentX;
        return;
      }
      const delta = currentX - prevXRef.current;
      prevXRef.current = currentX;

      const video = videoRef.current;
      if (!video || !video.duration) return;

      const SENSITIVITY = 0.8;
      const timeDelta = (delta / window.innerWidth) * SENSITIVITY * video.duration;

      targetTimeRef.current = Math.min(Math.max(0, targetTimeRef.current + timeDelta), video.duration);
      seekToTarget();
    };

    const handleTouchEnd = () => {
      prevXRef.current = null;
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseleave', handleMouseLeave);
    window.addEventListener('touchmove', handleTouchMove, { passive: true });
    window.addEventListener('touchend', handleTouchEnd);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, [seekToTarget]);

  // Copy email helper
  const handleCopyEmail = (e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    navigator.clipboard.writeText('hello@designfarry.com');
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2200);
  };

  // Open creator studio specifically for a category (Admin only)
  const openCreatorStudioForCategory = (cat?: ProjectCategory) => {
    setInitialStudioCategory(cat || null);
    setInitialStudioEditProject(null);
    setCreatorStudioOpen(true);
  };

  // Open creator studio to edit a specific project and save changes (Admin only)
  const openCreatorStudioForEdit = (project: Project) => {
    setInitialStudioEditProject(project);
    setInitialStudioCategory(project.category);
    setCreatorStudioOpen(true);
  };

  // Inquire about specific project or service
  const handleInquirePrefill = (prefilledService: string) => {
    setFormData((prev) => ({
      ...prev,
      serviceType: prefilledService,
      message: `Hi Farry, I saw your work on ${prefilledService} and would love to discuss a project...`,
    }));
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // COMPLETE LIST OF ALL PORTFOLIO CATEGORIES FOR PUBLIC VISITORS & CLIENTS
  const allPortfolioCategories: string[] = ['All', ...CATEGORIES];

  // Filtered projects visible to audience / clients
  const filteredProjects =
    selectedCategory === 'All'
      ? projects
      : projects.filter((p) => matchCategory(p.category, selectedCategory));

  // Handle keyboard shortcuts (Escape to close, Shift+C to toggle Creator Studio)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setActiveCaseStudy(null);
        setCreatorStudioOpen(false);
        setMobileMenuOpen(false);
      }
      // Creator shortcut: Shift + C
      if (e.shiftKey && (e.key === 'C' || e.key === 'c')) {
        const tag = document.activeElement?.tagName?.toLowerCase();
        if (tag !== 'input' && tag !== 'textarea') {
          e.preventDefault();
          setCreatorStudioOpen((prev) => !prev);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="min-h-screen bg-[#09090b] text-[#f4f4f5] selection:bg-white selection:text-black antialiased font-sans">
      {/* 0. PRIVATE CREATOR TOP BAR (ONLY VISIBLE TO ADMIN / CREATOR WHEN LOGGED IN) */}
      {isCreatorLoggedIn && (
        <div className="sticky top-0 z-50 w-full bg-emerald-950/95 text-emerald-200 border-b border-emerald-500/30 px-6 py-2.5 backdrop-blur-md flex flex-wrap items-center justify-between gap-3 text-xs shadow-lg">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-semibold text-white">Admin Creator Mode</span>
            <span className="text-emerald-400/80 hidden sm:inline">&middot; Post work visible to clients:</span>
          </div>

          {/* Quick Post options for all types: Brand, Poster, Package, Advertising, Social Media, Editorial, Other */}
          <div className="flex flex-wrap items-center gap-1.5">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => openCreatorStudioForCategory(cat)}
                className="px-2.5 py-1 rounded bg-emerald-900/70 hover:bg-emerald-800 text-white font-medium border border-emerald-400/30 hover:border-emerald-400 transition-all cursor-pointer flex items-center gap-1 text-[11px]"
                title={`Post a new ${cat} project (published directly to clients)`}
              >
                <span>+</span>
                <span>{cat}</span>
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => openCreatorStudioForCategory()}
              className="text-white hover:underline font-semibold"
            >
              Creator Studio ({projects.length})
            </button>
            <button
              onClick={() => {
                logoutCreator();
                setIsCreatorLoggedIn(false);
              }}
              className="text-emerald-300/70 hover:text-white"
            >
              Exit Creator Mode
            </button>
          </div>
        </div>
      )}

      {/* 1. TOP BAR NAVIGATION (FOR CLIENTS & VISITORS) */}
      <header
        className={`fixed left-0 right-0 z-40 w-full bg-[#09090b]/85 backdrop-blur-md border-b border-white/10 px-6 sm:px-10 py-4 flex items-center justify-between gap-8 transition-all ${
          isCreatorLoggedIn ? 'top-[41px]' : 'top-0'
        }`}
      >
        {/* Brand Zone */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href="/"
            className="text-xl sm:text-2xl font-bold tracking-tight text-white whitespace-nowrap"
            style={{ fontFamily: 'var(--font-heading)' }}
          >
            design.farry
          </a>
          <span
            aria-hidden="true"
            className="text-2xl text-neutral-400 select-none tracking-[-0.02em] leading-none inline-block transform translate-y-[-1px]"
          >
            &#10035;&#xfe0e;
          </span>
        </div>

        {/* 4–5 Clean Nav Links */}
        <nav aria-label="Main" className="hidden md:flex items-center gap-8 text-sm font-medium text-neutral-300">
          <a href="#portfolio" className="hover:text-white transition-colors whitespace-nowrap">
            Work {projects.length > 0 ? `(${projects.length})` : ''}
          </a>
          <a href="#about" className="hover:text-white transition-colors whitespace-nowrap">
            About
          </a>
          <a href="#services" className="hover:text-white transition-colors whitespace-nowrap">
            Services
          </a>
          <a href="#philosophy" className="hover:text-white transition-colors whitespace-nowrap">
            Manifesto
          </a>
          <a href="#contact" className="hover:text-white transition-colors whitespace-nowrap">
            Contact
          </a>
        </nav>

        {/* Primary Action Button */}
        <div className="hidden md:flex items-center gap-3 shrink-0">
          <a
            href="#contact"
            className="px-5 py-2 text-xs font-semibold uppercase tracking-wider text-black bg-white rounded-full hover:bg-neutral-200 transition-colors whitespace-nowrap cursor-pointer"
          >
            Start a Project
          </a>
        </div>

        {/* Mobile Hamburger Button */}
        <button
          type="button"
          onClick={() => setMobileMenuOpen((prev) => !prev)}
          aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
          aria-expanded={mobileMenuOpen}
          className="md:hidden flex flex-col justify-center items-center w-8 h-8 gap-[5px] cursor-pointer p-1 focus:outline-none"
        >
          <span
            className={`w-6 h-[2px] bg-white transition-all duration-300 origin-center ${
              mobileMenuOpen ? 'rotate-45 translate-y-[7px]' : ''
            }`}
          />
          <span
            className={`w-6 h-[2px] bg-white transition-all duration-300 ${
              mobileMenuOpen ? 'opacity-0' : 'opacity-100'
            }`}
          />
          <span
            className={`w-6 h-[2px] bg-white transition-all duration-300 origin-center ${
              mobileMenuOpen ? '-rotate-45 -translate-y-[7px]' : ''
            }`}
          />
        </button>
      </header>

      {/* Mobile Navigation Drawer */}
      <div
        className={`fixed inset-0 bg-neutral-950/95 backdrop-blur-xl z-30 flex flex-col justify-center px-8 gap-6 transition-opacity duration-300 md:hidden ${
          mobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <a
          href="#portfolio"
          onClick={() => setMobileMenuOpen(false)}
          className="text-3xl font-medium text-white hover:opacity-60 transition-opacity"
        >
          Work {projects.length > 0 ? `(${projects.length})` : ''}
        </a>
        <a
          href="#about"
          onClick={() => setMobileMenuOpen(false)}
          className="text-3xl font-medium text-white hover:opacity-60 transition-opacity"
        >
          About
        </a>
        <a
          href="#services"
          onClick={() => setMobileMenuOpen(false)}
          className="text-3xl font-medium text-white hover:opacity-60 transition-opacity"
        >
          Services
        </a>
        <a
          href="#philosophy"
          onClick={() => setMobileMenuOpen(false)}
          className="text-3xl font-medium text-white hover:opacity-60 transition-opacity"
        >
          Manifesto
        </a>
        <a
          href="#contact"
          onClick={() => setMobileMenuOpen(false)}
          className="text-3xl font-medium text-white underline underline-offset-4 hover:opacity-60 transition-opacity"
        >
          Start a Project
        </a>
      </div>

      {/* 2. HERO SECTION */}
      <section className="relative min-h-screen flex flex-col justify-between pt-28 pb-12 px-6 sm:px-10 lg:px-16 overflow-hidden border-b border-white/10">
        {/* Background interactive video overlay */}
        <div className="absolute inset-0 z-0 opacity-40 mix-blend-screen pointer-events-none">
          <video
            ref={videoRef}
            src="/aria.mp4"
            muted
            playsInline
            preload="auto"
            onSeeked={handleSeeked}
            onLoadedMetadata={() => {
              if (videoRef.current) {
                targetTimeRef.current = videoRef.current.currentTime;
              }
            }}
            className="w-full h-full object-cover"
            style={{ objectPosition: '85% center' }}
          >
            <source src="/aria.mp4" type="video/mp4" />
          </video>
          <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/60 to-transparent" />
        </div>

        {/* Top Kicker & Availability */}
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4 text-xs text-neutral-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="font-medium text-neutral-300">Currently Booking Q3/Q4 2026</span>
          </div>
          <div className="flex items-center gap-3">
            <span>Independent Graphic Design &amp; Visual Direction</span>
            <span aria-hidden="true">·</span>
            <span>Delhi, India &middot; Global</span>
          </div>
        </div>

        {/* Main Headline & Typewriter Intro */}
        <div className="relative z-10 max-w-4xl my-auto py-12 space-y-8">
          <h1
            className="text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight text-white leading-[1.08] text-balance"
            style={{ fontFamily: 'var(--font-heading)' }}
          >
            Visual direction &amp; graphic design built with architectural rigor.
          </h1>

          {/* Typewriter text introduction */}
          <div className="max-w-2xl min-h-[64px]">
            <p className="text-lg sm:text-xl text-neutral-300 leading-relaxed font-normal">
              {displayed}
              {!done && (
                <span
                  aria-hidden="true"
                  className="inline-block w-[2px] h-[1.1em] bg-white align-middle ml-[2px] animate-blink"
                />
              )}
            </p>
          </div>

          {/* Call to Actions */}
          <div className="flex flex-wrap items-center gap-4 pt-2">
            <a
              href="#portfolio"
              className="px-7 py-3 rounded-full bg-white text-black font-semibold text-sm hover:bg-neutral-200 transition-colors shadow-lg shadow-white/5 cursor-pointer"
            >
              Explore Selected Work
            </a>
            <a
              href="#services"
              className="px-6 py-3 rounded-full bg-neutral-900 border border-white/15 text-neutral-200 font-medium text-sm hover:bg-neutral-800 hover:text-white transition-colors cursor-pointer"
            >
              View Capabilities
            </a>
            <button
              onClick={handleCopyEmail}
              className="px-5 py-3 text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer flex items-center gap-2"
            >
              <span>{copiedEmail ? 'Copied hello@designfarry.com!' : 'hello@designfarry.com'}</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="9" y="9" width="13" height="13" rx="2" />
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
              </svg>
            </button>
          </div>
        </div>

        {/* Interactive Scrub Hint & Anchor Ribbon */}
        <div className="relative z-10 pt-8 border-t border-white/10 flex flex-wrap items-center justify-between gap-4 text-xs text-neutral-400">
          <div className="flex items-center gap-2">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M7 16l-4-4m0 0l4-4m-4 4h18m-4 4l4-4m0 0l-4-4" />
            </svg>
            <span>Move cursor horizontally across screen to scrub background kinetic reel</span>
          </div>
          <div className="flex items-center gap-4 text-neutral-400">
            <span>Identity Systems</span>
            <span aria-hidden="true">&bull;</span>
            <span>Exhibition Posters</span>
            <span aria-hidden="true">&bull;</span>
            <span>Artisanal Packaging</span>
            <span aria-hidden="true">&bull;</span>
            <span>Editorial Campaigns</span>
          </div>
        </div>
      </section>

      {/* 3. PORTFOLIO SECTION (PUBLIC WORK DISPLAY FOR CLIENTS & AUDIENCE) */}
      <section id="portfolio" className="py-24 px-6 sm:px-10 lg:px-16 border-b border-white/10">
        <div className="max-w-7xl mx-auto space-y-12">
          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-white/10">
            <div>
              <div className="text-xs font-semibold uppercase tracking-widest text-neutral-400 mb-2">
                01. Curated Portfolio
              </div>
              <h2
                className="text-3xl sm:text-5xl font-bold tracking-tight text-white"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                Selected Works &amp; Design Systems
              </h2>
            </div>
            <p className="text-sm text-neutral-400 max-w-md">
              A curated archive of genuine graphic design projects by Farry. Each case study documents the brief, conceptual thinking, and visual deliverables.
            </p>
          </div>

          {/* ADMIN-ONLY QUICK POST SHORTCUTS (ONLY VISIBLE WHEN YOU AS CREATOR ARE LOGGED IN) */}
          {isCreatorLoggedIn && (
            <div className="p-5 rounded-2xl bg-neutral-900/80 border border-emerald-500/40 space-y-3 shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    Creator Post Center (Admin Mode)
                  </span>
                </div>
                <span className="text-[11px] text-neutral-300">
                  Click any type to post work immediately visible to clients:
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => openCreatorStudioForCategory(cat)}
                    className="px-3.5 py-1.5 rounded-lg bg-neutral-950 hover:bg-emerald-400 hover:text-black text-white text-xs font-semibold border border-emerald-500/30 hover:border-emerald-400 transition-all cursor-pointer flex items-center gap-1.5 shadow-sm"
                  >
                    <span>+</span>
                    <span>Post {cat}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* PUBLIC CATEGORY FILTER TABS FOR CLIENTS / AUDIENCE (ALL CATEGORIES PRESENT) */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-neutral-900/80 rounded-xl border border-white/10 w-fit">
            {allPortfolioCategories.map((cat) => {
              const count =
                cat === 'All'
                  ? projects.length
                  : projects.filter((p) => matchCategory(p.category, cat)).length;
              const isSelected = selectedCategory === cat;

              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-2 text-xs font-medium rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-white text-black shadow-sm font-semibold'
                      : 'text-neutral-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <span>{cat}</span>
                  {count > 0 && (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                        isSelected
                          ? 'bg-neutral-200 text-black font-mono'
                          : 'bg-white/10 text-neutral-300 font-mono'
                      }`}
                    >
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Portfolio Layout: Either Real Projects Grid OR Category Empty State */}
          {filteredProjects.length === 0 ? (
            <div className="p-12 sm:p-16 rounded-2xl border border-white/10 bg-neutral-950/60 text-center max-w-2xl mx-auto space-y-6">
              <div className="w-16 h-16 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center mx-auto text-neutral-300">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
                  <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
                </svg>
              </div>

              <div className="space-y-2">
                <h3
                  className="text-2xl font-bold text-white tracking-tight"
                  style={{ fontFamily: 'var(--font-heading)' }}
                >
                  {selectedCategory === 'All'
                    ? 'Portfolio Curation in Progress'
                    : `No ${selectedCategory} Projects Published Yet`}
                </h3>
                <p className="text-sm text-neutral-400 leading-relaxed max-w-md mx-auto">
                  {selectedCategory === 'All'
                    ? 'All previous sample and demo projects have been cleared. As Farry posts real work, it will appear here for visitors and clients.'
                    : `Farry has not yet published a project in ${selectedCategory}. Check other categories or request custom credentials.`}
                </p>
              </div>

              <div className="pt-2 flex flex-wrap items-center justify-center gap-4">
                <button
                  onClick={() =>
                    handleInquirePrefill(
                      selectedCategory !== 'All' ? selectedCategory : 'Brand & Graphic Design'
                    )
                  }
                  className="px-6 py-2.5 rounded-full bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition-colors cursor-pointer"
                >
                  Inquire About {selectedCategory !== 'All' ? selectedCategory : 'Custom Projects'} &rarr;
                </button>
                <a
                  href="#services"
                  className="px-5 py-2.5 rounded-full bg-neutral-900 border border-white/15 text-xs text-neutral-300 hover:text-white transition-colors cursor-pointer"
                >
                  View Design Capabilities
                </a>

                {/* Creator Only Shortcut: Only displayed when creator Farry is logged in */}
                {isCreatorLoggedIn && (
                  <button
                    onClick={() =>
                      openCreatorStudioForCategory(
                        selectedCategory !== 'All'
                          ? (selectedCategory as ProjectCategory)
                          : 'Brand'
                      )
                    }
                    className="px-5 py-2.5 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-xs hover:bg-emerald-900 transition-colors cursor-pointer flex items-center gap-1.5 shadow-md"
                  >
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <rect x="3" y="11" width="18" height="11" rx="2" />
                      <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                    </svg>
                    <span>
                      + Post {selectedCategory !== 'All' ? selectedCategory : 'Real Work'} (Admin Mode)
                    </span>
                  </button>
                )}
              </div>
            </div>
          ) : (
            /* REAL PROJECTS PUBLISHED BY FARRY VISIBLE TO AUDIENCE & CLIENTS */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProjects.map((project, idx) => (
                <div
                  key={project.id}
                  onClick={() => setActiveCaseStudy(project)}
                  className={`group relative rounded-2xl bg-neutral-900/60 border border-white/10 hover:border-white/30 overflow-hidden transition-all duration-300 cursor-pointer flex flex-col ${
                    idx === 0 && filteredProjects.length >= 3 ? 'md:col-span-2' : ''
                  }`}
                >
                  {/* Image Container with preserved aspect ratio */}
                  <div className="relative w-full overflow-hidden bg-neutral-950 aspect-[4/3] sm:aspect-auto sm:h-80 flex items-center justify-center">
                    {project.coverImage ? (
                      <img
                        src={project.coverImage}
                        alt={project.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                    ) : (
                      <div className="p-8 text-center space-y-2">
                        <div className="text-xs uppercase font-semibold text-neutral-500 tracking-wider">
                          {project.category}
                        </div>
                        <div className="text-lg font-bold text-neutral-300">{project.title}</div>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />

                    {/* Category subtle badge */}
                    <div className="absolute top-4 right-4 px-3 py-1 bg-black/70 backdrop-blur-md text-[11px] font-medium text-neutral-300 rounded border border-white/10">
                      {project.category}
                    </div>

                    {/* Admin only: Quick edit & save trigger on card */}
                    {isCreatorLoggedIn && (
                      <div className="absolute top-4 left-4 z-10">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            openCreatorStudioForEdit(project);
                          }}
                          className="px-2.5 py-1 bg-neutral-900/90 hover:bg-emerald-500 hover:text-black text-emerald-300 hover:text-black text-[11px] font-semibold rounded border border-emerald-500/40 transition-colors shadow-sm cursor-pointer flex items-center gap-1"
                          title="Edit this project's details and save updates"
                        >
                          <span>✎</span>
                          <span>Edit &amp; Save</span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Card Content & Metadata */}
                  <div className="p-6 flex flex-col justify-between flex-1 space-y-4">
                    <div>
                      <div className="flex items-center gap-2 text-xs text-neutral-400 mb-2">
                        {project.year && <span>{project.year}</span>}
                        {project.client && (
                          <>
                            <span aria-hidden="true">&middot;</span>
                            <span className="truncate">{project.client}</span>
                          </>
                        )}
                      </div>
                      <h3
                        className="text-2xl font-bold tracking-tight text-white group-hover:text-neutral-200 transition-colors"
                        style={{ fontFamily: 'var(--font-heading)' }}
                      >
                        {project.title}
                      </h3>
                      {project.tagline && (
                        <p className="text-sm text-neutral-400 line-clamp-2 mt-2 leading-relaxed">
                          {project.tagline}
                        </p>
                      )}
                    </div>

                    {/* View Details affordance */}
                    <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs font-semibold text-neutral-300 group-hover:text-white">
                      <span>Inspect Case Study</span>
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        className="transform group-hover:translate-x-1 transition-transform"
                      >
                        <line x1="5" y1="12" x2="19" y2="12" />
                        <polyline points="12 5 19 12 12 19" />
                      </svg>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* 4. ABOUT SECTION */}
      <section id="about" className="py-24 px-6 sm:px-10 lg:px-16 border-b border-white/10 bg-neutral-950/40">
        <div className="max-w-7xl mx-auto space-y-16">
          <div className="border-b border-white/10 pb-6">
            <div className="text-xs font-semibold uppercase tracking-widest text-neutral-400 mb-2">
              02. About Farry
            </div>
            <h2
              className="text-3xl sm:text-5xl font-bold tracking-tight text-white"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Independent Graphic Designer &amp; Visual Director
            </h2>
          </div>

          {/* 2-Column Split: Portrait + Biography */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            {/* Left: Designer Portrait */}
            <div className="lg:col-span-5 space-y-4">
              <div className="rounded-2xl overflow-hidden border border-white/10 bg-neutral-900 shadow-2xl">
                <img
                  src="/src/assets/images/designer_portrait_farry_1791554764170.jpg"
                  alt="Farry - Graphic Designer & Visual Director"
                  referrerPolicy="no-referrer"
                  className="w-full h-auto object-cover aspect-square"
                />
              </div>
              <div className="p-4 rounded-xl bg-neutral-900/40 border border-white/5 text-xs text-neutral-400 space-y-1">
                <div className="font-semibold text-white">Farry &middot; Studio Lead</div>
                <div>Based in Delhi, India &middot; Working globally</div>
                <div className="pt-2 text-[11px] text-neutral-400">Specializing in Typography, Brand Systems &amp; Tactile Print Production</div>
              </div>
            </div>

            {/* Right: Studio Bio & Disciplines */}
            <div className="lg:col-span-7 space-y-8">
              <div className="space-y-6 text-base sm:text-lg text-neutral-300 leading-relaxed">
                <p>
                  I approach graphic design as visual architecture. With over eight years crafting identities for architecture practices, cultural exhibitions, and independent distilleries, my work balances rigorous Swiss grid discipline with organic, sensory tactile finishes.
                </p>
                <p className="text-neutral-400 text-sm sm:text-base">
                  In a world overflowing with disposable digital graphics, I focus on timeless design assets: custom-drawn display typography, heavyweight cotton stationery, deeply embossed packaging, and high-contrast editorial posters that command authority across both print and digital mediums.
                </p>
              </div>

              {/* Core Disciplines List */}
              <div className="pt-6 border-t border-white/10">
                <h3 className="text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-4">
                  Core Disciplines &amp; Craft Competencies
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-neutral-900/60 border border-white/5">
                    <div className="text-sm font-semibold text-white mb-1">Brand Architecture</div>
                    <p className="text-xs text-neutral-400">Logomarks, design tokens, brand manuals, and scalable typographic hierarchies.</p>
                  </div>
                  <div className="p-4 rounded-xl bg-neutral-900/60 border border-white/5">
                    <div className="text-sm font-semibold text-white mb-1">Custom Typography</div>
                    <p className="text-xs text-neutral-400">Bespoke glyph sets, optical kerning, baseline grid systems, and font licensing curation.</p>
                  </div>
                  <div className="p-4 rounded-xl bg-neutral-900/60 border border-white/5">
                    <div className="text-sm font-semibold text-white mb-1">Editorial &amp; Print</div>
                    <p className="text-xs text-neutral-400">Large-format exhibition posters, monographs, art catalogs, and pre-press prep.</p>
                  </div>
                  <div className="p-4 rounded-xl bg-neutral-900/60 border border-white/5">
                    <div className="text-sm font-semibold text-white mb-1">Tactile Packaging</div>
                    <p className="text-xs text-neutral-400">Substrate selection, foil stamping, embossing dies, and sustainable packaging structures.</p>
                  </div>
                </div>
              </div>

              {/* Tools & Production Partners */}
              <div className="pt-4 border-t border-white/10 flex flex-wrap gap-4 text-xs text-neutral-400">
                <span>Tools: Glyphs &middot; InDesign &middot; Illustrator &middot; Figma &middot; Blender</span>
                <span aria-hidden="true">&middot;</span>
                <span>Print: Silk-Screen &middot; Letterpress &middot; Offset Lithography &middot; Hot Foil</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. PHILOSOPHY / MANIFESTO SECTION */}
      <section id="philosophy" className="py-24 px-6 sm:px-10 lg:px-16 border-b border-white/10">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="border-b border-white/10 pb-6">
            <div className="text-xs font-semibold uppercase tracking-widest text-neutral-400 mb-2">
              03. Design Philosophy
            </div>
            <h2
              className="text-3xl sm:text-5xl font-bold tracking-tight text-white"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Four Principles Guiding Every Project
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {PHILOSOPHY_PRINCIPLES.map((item) => (
              <div
                key={item.number}
                className="p-6 rounded-2xl bg-neutral-900/40 border border-white/10 hover:border-white/20 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="font-mono text-xs text-neutral-400 mb-4">{item.number}</div>
                  <h3
                    className="text-lg font-bold text-white mb-3 tracking-tight"
                    style={{ fontFamily: 'var(--font-heading)' }}
                  >
                    {item.title}
                  </h3>
                  <p className="text-sm text-neutral-400 leading-relaxed">
                    {item.text}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. SERVICES SECTION */}
      <section id="services" className="py-24 px-6 sm:px-10 lg:px-16 border-b border-white/10 bg-neutral-950/40">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-white/10">
            <div>
              <div className="text-xs font-semibold uppercase tracking-widest text-neutral-400 mb-2">
                04. Capabilities &amp; Services
              </div>
              <h2
                className="text-3xl sm:text-5xl font-bold tracking-tight text-white"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                End-to-End Graphic Design Services
              </h2>
            </div>
            <p className="text-sm text-neutral-400 max-w-md">
              Comprehensive design engagements structured for founders, creative directors, and institutions ready to invest in enduring visual equity.
            </p>
          </div>

          {/* Interactive Service Accordion / Deck */}
          <div className="space-y-4">
            {SERVICES.map((srv, idx) => {
              const isOpen = activeServiceTab === idx;
              return (
                <div
                  key={srv.index}
                  className="rounded-2xl border border-white/10 bg-neutral-900/50 overflow-hidden transition-all"
                >
                  <button
                    type="button"
                    onClick={() => setActiveServiceTab(isOpen ? -1 : idx)}
                    className="w-full px-6 sm:px-8 py-6 flex items-center justify-between gap-4 text-left hover:bg-white/5 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-4 sm:gap-6">
                      <span className="font-mono text-xs text-neutral-400">{srv.index}</span>
                      <h3
                        className="text-xl sm:text-2xl font-bold text-white tracking-tight"
                        style={{ fontFamily: 'var(--font-heading)' }}
                      >
                        {srv.title}
                      </h3>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="hidden sm:inline-block text-xs text-neutral-400">
                        {srv.typicalTimeline}
                      </span>
                      <div className="p-1 rounded-full border border-white/20 text-neutral-400">
                        <svg
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          className={`transform transition-transform ${isOpen ? 'rotate-180' : ''}`}
                        >
                          <polyline points="6 9 12 15 18 9" />
                        </svg>
                      </div>
                    </div>
                  </button>

                  {isOpen && (
                    <div className="px-6 sm:px-8 pb-8 pt-2 border-t border-white/5 space-y-6">
                      <p className="text-sm sm:text-base text-neutral-300 leading-relaxed max-w-3xl">
                        {srv.details}
                      </p>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                        <div>
                          <div className="text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-3">
                            Key Deliverables Included
                          </div>
                          <ul className="space-y-2">
                            {srv.deliverables.map((d) => (
                              <li key={d} className="flex items-start gap-2 text-xs text-neutral-300">
                                <span className="text-white font-bold">&ndash;</span>
                                <span>{d}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="flex flex-col justify-between p-5 rounded-xl bg-neutral-950 border border-white/10">
                          <div>
                            <div className="text-xs text-neutral-400 mb-1">Standard Production Timeline</div>
                            <div className="text-base font-semibold text-white mb-2">{srv.typicalTimeline}</div>
                            <p className="text-xs text-neutral-400">
                              Tailored to project milestones, print sample approvals, and client review rounds.
                            </p>
                          </div>
                          <button
                            onClick={() => handleInquirePrefill(srv.title)}
                            className="mt-4 px-5 py-2.5 rounded-full bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition-colors w-fit cursor-pointer"
                          >
                            Inquire about this capability &rarr;
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 7. CONTACT SECTION */}
      <section id="contact" className="py-24 px-6 sm:px-10 lg:px-16 border-b border-white/10">
        <div className="max-w-7xl mx-auto space-y-16">
          <div className="border-b border-white/10 pb-6">
            <div className="text-xs font-semibold uppercase tracking-widest text-neutral-400 mb-2">
              05. Inquiries &amp; Collaboration
            </div>
            <h2
              className="text-3xl sm:text-5xl font-bold tracking-tight text-white max-w-3xl"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Have a project in mind? Let&apos;s build something enduring.
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            {/* Left: Direct Contact Information */}
            <div className="lg:col-span-5 space-y-8">
              <div className="space-y-4">
                <div className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                  Direct Inquiries
                </div>
                <div className="flex items-center gap-3">
                  <a
                    href="mailto:hello@designfarry.com"
                    className="text-2xl font-semibold text-white hover:underline underline-offset-4"
                  >
                    hello@designfarry.com
                  </a>
                  <button
                    onClick={handleCopyEmail}
                    className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
                    title="Copy email to clipboard"
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <rect x="9" y="9" width="13" height="13" rx="2" />
                      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                    </svg>
                  </button>
                </div>
                {copiedEmail && (
                  <p className="text-xs text-emerald-400 font-medium">Email copied to clipboard!</p>
                )}
                <p className="text-sm text-neutral-400 leading-relaxed">
                  I review inbound inquiries directly. For brand identities and packaging commissions, booking 3–4 weeks in advance is recommended.
                </p>
              </div>

              {/* Studio Locations */}
              <div className="p-5 rounded-2xl bg-neutral-900/60 border border-white/5 space-y-3">
                <div className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                  Studio Presence
                </div>
                <div className="text-sm text-neutral-200">
                  Delhi, India &middot; Remote Worldwide
                </div>
                <div className="text-xs text-neutral-400">
                  Response SLA: Within 24–48 business hours
                </div>
              </div>

              {/* Social and Curated Links */}
              <div className="space-y-3">
                <div className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                  Selected Profiles &amp; Archives
                </div>
                <div className="flex flex-wrap gap-4 text-xs font-medium text-neutral-300">
                  <a
                    href="https://read.cv"
                    target="_blank"
                    rel="noreferrer"
                    className="hover:text-white underline underline-offset-2"
                  >
                    ReadCV &nearr;
                  </a>
                  <a
                    href="https://are.na"
                    target="_blank"
                    rel="noreferrer"
                    className="hover:text-white underline underline-offset-2"
                  >
                    Are.na &nearr;
                  </a>
                  <a
                    href="https://behance.net"
                    target="_blank"
                    rel="noreferrer"
                    className="hover:text-white underline underline-offset-2"
                  >
                    Behance &nearr;
                  </a>
                  <a
                    href="https://instagram.com"
                    target="_blank"
                    rel="noreferrer"
                    className="hover:text-white underline underline-offset-2"
                  >
                    Instagram &nearr;
                  </a>
                </div>
              </div>
            </div>

            {/* Right: Working Inquiry Form */}
            <div className="lg:col-span-7 p-6 sm:p-8 rounded-2xl bg-neutral-900/80 border border-white/10">
              {formSubmitted ? (
                <div className="py-12 text-center space-y-4">
                  <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </div>
                  <h3
                    className="text-2xl font-bold text-white tracking-tight"
                    style={{ fontFamily: 'var(--font-heading)' }}
                  >
                    Inquiry Received
                  </h3>
                  <p className="text-sm text-neutral-300 max-w-md mx-auto leading-relaxed">
                    Thank you, {formData.name || 'there'}. I have received your project details and will follow up with initial scheduling thoughts and design scope.
                  </p>
                  <button
                    onClick={() => {
                      setFormSubmitted(false);
                      setFormData({
                        name: '',
                        email: '',
                        serviceType: 'Brand Identity',
                        budget: '$6,000–$12,000',
                        timeline: '1–2 Months',
                        message: '',
                      });
                    }}
                    className="px-6 py-2.5 rounded-full bg-neutral-800 text-xs font-semibold text-white hover:bg-neutral-700 transition-colors cursor-pointer"
                  >
                    Send another inquiry
                  </button>
                </div>
              ) : (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    setFormSubmitted(true);
                  }}
                  className="space-y-6"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        Your Name *
                      </label>
                      <input
                        required
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Elena Rostova"
                        className="w-full px-4 py-3 rounded-xl bg-neutral-950 border border-white/10 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-white transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        Email Address *
                      </label>
                      <input
                        required
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="elena@studio.com"
                        className="w-full px-4 py-3 rounded-xl bg-neutral-950 border border-white/10 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-white transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        Project Scope
                      </label>
                      <select
                        value={formData.serviceType}
                        onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
                        className="w-full px-3 py-3 rounded-xl bg-neutral-950 border border-white/10 text-xs text-white focus:outline-none focus:border-white"
                      >
                        <option value="Brand Identity">Brand Identity &amp; Systems</option>
                        <option value="Editorial &amp; Poster">Editorial &amp; Posters</option>
                        <option value="Bespoke Packaging">Bespoke Packaging</option>
                        <option value="Campaign Creatives">Campaign &amp; Advertising</option>
                        <option value="Social &amp; Digital">Social &amp; Motion Direction</option>
                        <option value="Other">Custom Commission</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        Estimated Budget
                      </label>
                      <select
                        value={formData.budget}
                        onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                        className="w-full px-3 py-3 rounded-xl bg-neutral-950 border border-white/10 text-xs text-white focus:outline-none focus:border-white"
                      >
                        <option value="$3,000–$6,000">$3,000 &ndash; $6,000</option>
                        <option value="$6,000–$12,000">$6,000 &ndash; $12,000</option>
                        <option value="$12,000–$25,000">$12,000 &ndash; $25,000</option>
                        <option value="$25,000+">$25,000+</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                        Desired Timeline
                      </label>
                      <select
                        value={formData.timeline}
                        onChange={(e) => setFormData({ ...formData, timeline: e.target.value })}
                        className="w-full px-3 py-3 rounded-xl bg-neutral-950 border border-white/10 text-xs text-white focus:outline-none focus:border-white"
                      >
                        <option value="Immediate">Immediate Start</option>
                        <option value="1–2 Months">Next 1–2 Months</option>
                        <option value="Q3/Q4 2026">Q3/Q4 2026</option>
                        <option value="Flexible">Exploratory / Flexible</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                      Project Vision &amp; Requirements *
                    </label>
                    <textarea
                      required
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Tell me about your brand, what deliverables you envision, and any key deadlines..."
                      className="w-full px-4 py-3 rounded-xl bg-neutral-950 border border-white/10 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-white transition-colors"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-full bg-white text-black font-semibold text-sm hover:bg-neutral-200 transition-colors shadow-md cursor-pointer"
                  >
                    Submit Project Inquiry &rarr;
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* 8. FOOTER WITH DISCREET CREATOR STUDIO ACCESS */}
      <footer className="py-12 px-6 sm:px-10 lg:px-16 bg-neutral-950 text-neutral-400 text-xs border-t border-white/10">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <span
              className="text-base font-bold text-white tracking-tight"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              design.farry
            </span>
            <span aria-hidden="true">&bull;</span>
            <span>Graphic Design &amp; Visual Direction</span>
          </div>

          <div className="flex items-center gap-6 text-neutral-400">
            <a href="#portfolio" className="hover:text-white transition-colors">
              Work
            </a>
            <a href="#about" className="hover:text-white transition-colors">
              About
            </a>
            <a href="#services" className="hover:text-white transition-colors">
              Services
            </a>
            <a href="#contact" className="hover:text-white transition-colors">
              Contact
            </a>
            {/* Creator controls are hidden from public visitors. Use ?creator=1 to sign in. */}
            {isCreatorLoggedIn && (
              <button
                onClick={() => openCreatorStudioForCategory()}
                className="text-emerald-400 hover:text-white transition-colors cursor-pointer flex items-center gap-1.5"
                title="Open private Creator Studio"
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="11" width="18" height="11" rx="2" />
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                </svg>
                <span>Creator Studio (Active)</span>
              </button>
            )}
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Back to Top &uarr;
            </button>
          </div>

          <div className="text-neutral-500">
            &copy; {new Date().getFullYear()} design.farry. All rights reserved.
          </div>
        </div>
      </footer>

      {/* 9. DEDICATED PROJECT CASE STUDY MODAL */}
      <CaseStudyModal
        project={activeCaseStudy}
        onClose={() => setActiveCaseStudy(null)}
        onInquire={handleInquirePrefill}
        isAdmin={isCreatorLoggedIn}
        onEditProject={(proj) => {
          setActiveCaseStudy(null);
          openCreatorStudioForEdit(proj);
        }}
      />

      {/* 10. CREATOR STUDIO PRIVATE ADMIN MODAL */}
      <CreatorStudioModal
        isOpen={creatorStudioOpen}
        onClose={() => {
          setCreatorStudioOpen(false);
          setInitialStudioEditProject(null);
          setIsCreatorLoggedIn(isCreatorAuthenticated());
        }}
        projects={projects}
        onProjectsUpdated={() => {
          reloadProjects();
          // If activeCaseStudy is currently open, refresh it with latest saved version
          if (activeCaseStudy) {
            const fresh = getSavedProjects().find((p) => p.id === activeCaseStudy.id);
            if (fresh) setActiveCaseStudy(fresh);
          }
        }}
        initialCategory={initialStudioCategory}
        initialEditProject={initialStudioEditProject}
      />
    </div>
  );
}
